<?php include "includes/header.php"; ?>
    <div class="container-fluid photos">
      <h2 id="indexH2" class="text-white mb-4 text-center" data-aos="fade-up">Here are some stuffs I have done</h2>
      <div class="row align-items-stretch">  
      <!-- end header -->

   
<!--        <h2 class="text-white mb-4 text-center" data-aos="fade-up">Website Design Portfolio</h2><br> -->
      
         <div id="stuffs">
       <?php
              $query = "SELECT * FROM stuffs";
              $select_all_stuffs_query = mysqli_query($connection, $query);

              while($row = mysqli_fetch_assoc( $select_all_stuffs_query)) {

              $stuffs_title = $row['stuffs_title'];
              $stuffs_tagline = $row['stuffs_tagline'];
              $stuffs_image = $row['stuffs_image'];
              $stuffs_id = $row['stuffs_id'];
              $stuffs_permalink = $row['stuffs_permalink'];
              $stuffs_desc = $row['stuffs_desc'];
                    
                      
         ?>
      
       
      
       
        
                <div id="stuffs-inner">
                    <a data-fancybox data-src="#<?php echo $stuffs_permalink; ?>" href class="d-block photo-item">
                        <img src="images/index/thumbnails/<?php echo $stuffs_image ?>" alt="Image" class="img-fluid">
                        <div class="photo-text-more">
                       
                            <h3 class="heading"><?php echo $stuffs_title ?></h3>
                            <span class="meta"><?php echo $stuffs_tagline ?></span>

                        
                        </div>
                    </a>
                </div>
           
           <div style="display:none;" id="<?php echo $stuffs_permalink; ?>"><?php echo $stuffs_desc; ?></div>
         
      
      <?php } ?>
            </div> <!-- stuffs -->
          
       <div id="quotes" class="fade">
         <div>
        <h1>"Adding quotes to website landing pages is stupid."</h1><br>
        <h3>-James Welbes</h3>
         </div>
        </div>
      
      <div id="thanks" class="fade">
         <div>
        <h1>Thank you for visiting JamesWelbes.com</h1><br>
        
         </div>
        </div>
      
      <div id="name" class="fade">
         <div>
           <h1>My name is.<span id="nameSpan">.</span><span id="nameSpan2">.</span></h1><br>
        
         </div>
        </div>
      
      
      
      <div id="insignificant" class="fade">
         <div>
        <h1>...insignificant.</h1><br>
        
         </div>
        </div>
      
      <div id="just" class="fade">
         <div>
           <h1>I'm just a guy, <span id="justSpan">who does stuff.</span></h1><br>
        
         </div>
        </div>
      
      <div id="stuff" class="fade">
         <div>
        <h1>I'm just a guy, who does stuff.</h1><br>
        
         </div>
        </div>
       

     

      <script>
        hideHeader();
        window.onload = function() {
            window.setTimeout(quotesIn, 1000); 
            window.setTimeout(quotesOut, 6000); 
            
            window.setTimeout(thanksIn, 8000);
            window.setTimeout(thanksOut, 12000);

            window.setTimeout(nameIn, 14000);
            window.setTimeout(nameSpan, 15000);
            window.setTimeout(nameSpan2, 16000);
            window.setTimeout(nameOut, 18000);

            window.setTimeout(insignificantIn, 20000);
            window.setTimeout(insignificantOut, 24000);
          
            window.setTimeout(justIn, 26000);
            window.setTimeout(justSpan, 28000);
            window.setTimeout(justOut, 30000);
          
            window.setTimeout(headerIn, 32000);
//           window.setTimeout(headerIn, 1000);
          
        
}
        
        function hideHeader() {
          document.getElementById('header').style.opacity = '0';
          console.log('yousuck');
        }
        function quotesIn () {
         document.getElementById('quotes').style.opacity = '1';
       
       }
        function quotesOut () {
         
         document.getElementById('quotes').style.opacity = '0';
       
       }
         function thanksIn () {
         document.getElementById('thanks').style.opacity = '1';
       
       }
        function thanksOut () {
         document.getElementById('thanks').style.opacity = '0';
       
       }
        function nameIn () {
         document.getElementById('name').style.opacity = '1';
       
       }
        function nameOut () {
         document.getElementById('name').style.opacity = '0';
       
       }
        
        function nameSpan () {
         document.getElementById('nameSpan').style.opacity = '1';
       
       }
        function nameSpan2 () {
         document.getElementById('nameSpan2').style.opacity = '1';
       
       }
        
        
        
        
         function insignificantIn () {
         document.getElementById('insignificant').style.opacity = '1';
       
       }
        function insignificantOut () {
         document.getElementById('insignificant').style.opacity = '0';
       
       }
        
         function justIn () {
         document.getElementById('just').style.opacity = '1';
       
       }
        function justOut () {
         document.getElementById('just').style.opacity = '0';
       
       }
        
        function justSpan () {
         document.getElementById('justSpan').style.opacity = '1';
       
       }
        function headerIn () {
         document.getElementById('header').style.opacity = '1';
           document.getElementById('stuffs').style.display = 'flex';
           document.getElementById('stuffs').style.opacity = '1';
          document.getElementById('indexH2').style.opacity = '1';
       
       }
        
        
      </script> 
      </div></div>
    <?php include "footer.php"; ?>