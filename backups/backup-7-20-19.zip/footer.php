
    
     </main>
    <footer id="footer">
    <div class="row justify-content-center">
        <div class="col-md-12 text-center py-5">
          <p>
       
      </p>
        </div> <!-- col-md-12 text-center py-5 -->
      </div><!-- row justify-content-center -->
    
 

</div> <!-- .site-wrap -->

  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/jquery.countdown.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/bootstrap-datepicker.min.js"></script>
<script src="js/hidemore.js"></script>
  <script src="js/aos.js"></script>

  <script src="js/jquery.fancybox.min.js"></script>

  <script src="js/main.js"></script>
<!--  <script src="js/script.js"></script> -->
</footer>
  </body>
</html>