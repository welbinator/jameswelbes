// function close () {
  
//   document.getElementById('main-content').classList.remove('main-content-menu-open');
//   document.getElementById('header-bar').classList.remove('header-bar-menu-open');
 
  
// }


// function where () {
//   document.getElementById('main-content').classList.add('main-content-menu-open');
//   document.getElementById('header-bar').classList.add('header-bar-menu-open');
//     document.getElementById('main-menu').style.display = "none";
//   document.getElementById('sub-menu').style.display = "block";
  
// }


var hideMore = function (elem) {
    var bounding = elem.getBoundingClientRect();
    return (
        bounding.top >= 0 &&
        bounding.left >= 0 &&
        bounding.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
        bounding.right <= (window.innerWidth || document.documentElement.clientWidth)
    );
};

var footer = document.getElementById('footer');
window.addEventListener('scroll', function (event) {
	if (hideMore(footer)) {
		document.getElementById('more').style.display = "none";
    console.log("hide");
	}
}, false);
