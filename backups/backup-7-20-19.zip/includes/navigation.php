<div class="main-menu">
      <ul class="js-clone-nav">
        <li class="active"><a href="index.php">Home</a></li>
        
        <li><a href="bio.php">Bio</a></li>
        
        <li><a href="contact.php">Contact</a></li>
        
        <li><a href="webdesign.php">Web Design</a></li>
      </ul>
     
  
  
  <ul class="social js-clone-nav">
        <li><a href="https://www.facebook.com/james.welbes"><span class="icon-facebook"></span></a></li>
        <li><a href="https://www.linkedin.com/in/jameswelbes/"><span class="icon-linkedin"></span></a></li>
        <li><a href="https://www.instagram.com/crweb.design/"><span class="icon-instagram"></span></a></li>
      </ul>
    </div>